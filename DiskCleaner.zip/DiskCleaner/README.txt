1. Extract file
2. Open DiskCleaner
3. Wait until its finish
4. Hope it reduced lag!

This will run as adminstrator cause if it wasn't the DiskCleaner would just crash and it wouldn't get access to your disk and clean it.
This was made by king and i hope you enjoy this.

Reduce Lag

This file will reduce your lag by emptying viruses.
And then the file will close cause if you play an game with it keeping it on it will lag your game of the scanning.
An gui ill open up and tell you what process you want to reduce lag from [supported is roblox right now].
What this will do is clean up any non necessary file and other files if the file is important we will tell you to delete it also you will need to have an braincells if its important or not to your pc and might fail your pc.